from random import randint
from sys import exit
import pygame
import os
from pygame.locals import *

pygame.init()
pygame.display.set_caption('Game')
WIDTH = 1920
HEIGHT = 1080
clock = pygame.time.Clock()
FPS = 50
screen = pygame.display.set_mode((WIDTH, HEIGHT))


def load_image(name, colorkey=None, transform=None):
    fullname = os.path.join("data/" + name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    if transform is not None:
        image = pygame.transform.rotate(image, transform)
    return image


between = 100
fon = load_image("fon.png")
fon = pygame.transform.scale(fon, (WIDTH, HEIGHT))
starting_fon = load_image("starting_fon.jpg")
starting_fon = pygame.transform.scale(starting_fon, (WIDTH, HEIGHT))
ground = load_image("ground.png")
ground = pygame.transform.scale(ground, (WIDTH, HEIGHT // 4))
player_image = load_image('player.png')
player_image = pygame.transform.scale(player_image, (35, 25))
pipe = load_image("pipe.png")
pipe_top = load_image("pipe.png", transform=180)


def terminate():
    pygame.quit()
    exit()


pipe_h_min = WIDTH // 8
pipe_h_max = WIDTH // 2
all_sprites = pygame.sprite.Group()
pipes_group = pygame.sprite.Group()
top_pipes = pygame.sprite.Group()
bottom_pipes = pygame.sprite.Group()
player_group = pygame.sprite.Group()

flight = False
game_over = False


class Pipe(pygame.sprite.Sprite):
    def __init__(self, x, y, loc="top"):
        super().__init__()
        self.image = pipe
        self.rect = self.image.get_rect()
        if loc == "top":
            top_pipes.add(self)
            self.image = pipe_top
            self.rect.bottomleft = [x, y - int(between / 2)]
        else:
            bottom_pipes.add(self)
            self.rect.topleft = [x, y + int(between / 2)]

    def update(self):
        self.rect.x -= offset
        if self.rect.right <= 0:
            self.kill()

    def pipes_coords(self):
        return self.rect


class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__(player_group, all_sprites)
        self.image = player_image
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

        self.mouse_clicked = False
        self.v = 0

    def update(self):
        if flight:
            self.v += 0.2
            if self.v > 20:
                self.v = 0
            if self.rect.bottom < HEIGHT - 20:
                self.rect.y += int(self.v)

        if not game_over:
            if pygame.mouse.get_pressed()[0] and not self.mouse_clicked:
                self.mouse_clicked = True
                self.v = -3
            if pygame.mouse.get_pressed()[0]:
                self.mouse_clicked = False
            self.rect.y += self.v


player = Player(WIDTH // 2, HEIGHT // 2)
ground_x = 0
offset = 2
score = 0
one_pipe_passed = False


def start_screen():
    intro_text = ["ЗАСТАВКА"]
    screen.blit(starting_fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, True, pygame.Color('white'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    global score, one_pipe_passed
    score = 0
    one_pipe_passed = False
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                return
        pygame.display.flip()
        clock.tick(FPS)


def game():
    global ground, ground_x, screen, flight, game_over, score, one_pipe_passed
    pygame.display.flip()
    ticks = 1800
    last_pipe = pygame.time.get_ticks() - ticks

    while True:
        if game_over:
            print(score + 1)
            return

        for event in pygame.event.get():
            if event.type == QUIT:
                terminate()
            if event.type == pygame.MOUSEBUTTONDOWN and not flight and not game_over:
                flight = True

        if pygame.sprite.groupcollide(player_group, pipes_group, False,
                                      False) or player.rect.y < 100 or player.rect.y > HEIGHT - 100:
            game_over = True

        if not game_over and flight:
            ground_x -= offset
            if abs(ground_x) > 20:
                ground_x = 0
            time_passed = pygame.time.get_ticks()
            if time_passed == ticks or time_passed - last_pipe > ticks:
                h = randint(0, 150)
                bot_pipe = Pipe(WIDTH, int(HEIGHT // 2) - h, loc="bot")
                top_pipe = Pipe(WIDTH, int(HEIGHT // 2) - h, loc="top")
                pipes_group.add(bot_pipe)
                pipes_group.add(top_pipe)
                last_pipe = time_passed
            if pipes_group:
                if pipes_group.sprites()[0].rect.left < player.rect.x < pipes_group.sprites()[0].rect.right\
                        and not one_pipe_passed:
                    one_pipe_passed = True
                if one_pipe_passed:
                    if player.rect.x > pipes_group.sprites()[0].rect.right:
                        score += 1
                        one_pipe_passed = False
            pipes_group.update()
            player_group.update()
            screen.blit(fon, (0, 0))
            pipes_group.draw(screen)
            screen.blit(ground, (ground_x, HEIGHT // 4 * 3))
            player_group.draw(screen)
            pygame.display.flip()
            clock.tick(FPS)


def end_screen():
    intro_text = ["КОНЦОВКА"]
    screen.blit(starting_fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, True, pygame.Color('white'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                return
        pygame.display.flip()
        clock.tick(FPS)


if __name__ == "__main__":
    start_screen()
    game()
    end_screen()
